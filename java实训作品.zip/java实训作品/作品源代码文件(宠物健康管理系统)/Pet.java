package 宠物健康管理系统;

import java.io.Serializable;

public class Pet implements Serializable {
    private int id;
    private String name;
    private String breed;
    private int age;
    private String gender;

    public Pet(int id, String name, String breed, int age, String gender) {
        this.id = id;
        this.name = name;
        this.breed = breed;
        this.age = age;
        this.gender = gender;
    }

    // 获取属性的方法
    public int getId() { return id; }
    public String getName() { return name; }
    public String getBreed() { return breed; }
    public int getAge() { return age; }
    public String getGender() { return gender; }


    @Override
    public String toString() {
        return "宠物信息{" +
                "ID=" + id +
                ", 名字='" + name + '\'' +
                ", 品种='" + breed + '\'' +
                ", 年龄=" + age +
                ", 性别='" + gender + '\'' +
                '}';
    }
}