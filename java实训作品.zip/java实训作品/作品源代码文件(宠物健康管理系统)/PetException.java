package 宠物健康管理系统;

public class PetException extends Exception {
    public PetException(String message) {
        super(message);
    }
}