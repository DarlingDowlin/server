package 宠物健康管理系统;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class PetManager {
    private List<Pet> pets = new ArrayList<>();
    private List<HealthRecord> healthRecords = new ArrayList<>();
    private static final String PET_FILE_PATH = "pets.dat";
    private static final String RECORD_FILE_PATH = "healthRecords.dat";

    // 录入宠物
    public void addPet(Pet pet) throws PetException {
        if (pet == null) {
            throw new PetException("宠物对象不能为空");
        }
        pets.add(pet);
    }

    // 查询宠物（按ID）
    public Pet findPetById(int id) {
        for (Pet p : pets) {
            if (p.getId() == id) {
                return p;
            }
        }
        return null;
    }

    // 删除宠物
    public boolean deletePet(int id) {
        Pet toDelete = findPetById(id);
        if (toDelete != null) {
            return pets.remove(toDelete);
        }
        return false;
    }





    // 添加健康记录
    public void addHealthRecord(HealthRecord record) throws PetException {
        if (record == null) {
            throw new PetException("健康记录对象不能为空");
        }
        healthRecords.add(record);
    }

    // 查询健康记录（按宠物ID）
    public List<HealthRecord> getHealthRecordsByPetId(int petId) {
        List<HealthRecord> result = new ArrayList<>();
        for (HealthRecord r : healthRecords) {
            if (r.getPetId() == petId) {
                result.add(r);
            }
        }
        return result;
    }






    // 保存宠物数据到文件
    private void savePetsToFile() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(PET_FILE_PATH))) {
            oos.writeObject(pets);
        } catch (IOException e) {
            System.out.println("保存宠物数据失败：" + e.getMessage());
        }
    }

    // 从文件加载宠物数据
    @SuppressWarnings("unchecked")
    private void loadPetsFromFile() {
        File file = new File(PET_FILE_PATH);
        if (!file.exists()) return;

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(PET_FILE_PATH))) {
            pets = (List<Pet>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("加载宠物数据失败：" + e.getMessage());
        }
    }


    private void saveHealthRecordsToFile() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(RECORD_FILE_PATH))) {
            oos.writeObject(healthRecords);
        } catch (IOException e) {
            System.out.println("保存健康记录失败：" + e.getMessage());
        }
    }
    @SuppressWarnings("unchecked")
    private void loadHealthRecordsFromFile() {
        File file = new File(RECORD_FILE_PATH);
        if (!file.exists()) return;

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(RECORD_FILE_PATH))) {
            healthRecords = (List<HealthRecord>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("加载健康记录失败：" + e.getMessage());
        }
    }
    public void newways(){
        loadPetsFromFile();
        loadHealthRecordsFromFile();
    }

    public void newways2(){
        savePetsToFile();
        saveHealthRecordsToFile();
    }
}