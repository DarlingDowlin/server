package 宠物健康管理系统;

public class PetManagerFactory {

    private PetManagerFactory() {}

    private static final PetManager INSTANCE = new PetManager();

    public static PetManager getInstance() {
        return INSTANCE;
    }
}