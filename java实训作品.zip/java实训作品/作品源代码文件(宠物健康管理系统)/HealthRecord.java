package 宠物健康管理系统;

import java.util.Date;
import java.io.Serializable;

public class HealthRecord implements Serializable {
    private int recordId;
    private int petId;
    private String recordType;
    private Date recordDate;
    private String details;

    public HealthRecord(int recordId, int petId, String recordType, Date recordDate, String details) {
        this.recordId = recordId;
        this.petId = petId;
        this.recordType = recordType;
        this.recordDate = recordDate;
        this.details = details;
    }

    // 获取属性的方法
    public int getRecordId() { return recordId; }
    public int getPetId() { return petId; }
    public String getRecordType() { return recordType; }
    public Date getRecordDate() { return recordDate; }
    public String getDetails() { return details; }


    @Override
    public String toString() {
        return "健康记录{" +
                "记录ID=" + recordId +
                ", 宠物ID=" + petId +
                ", 类型='" + recordType + '\'' +
                ", 日期=" + recordDate +
                ", 详情='" + details + '\'' +
                '}';
    }
}