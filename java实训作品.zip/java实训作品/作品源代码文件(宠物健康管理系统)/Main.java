package 宠物健康管理系统;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static final Scanner input = new Scanner(System.in);
    // 通过工厂类获取 PetManager 实例
    private static final PetManager manager = PetManagerFactory.getInstance();

    public static void main(String[] args) {
        manager.newways();

        showMenu();
    }

    private static void showMenu() {
        while (true) {
            System.out.println("\n==== 宠物健康管理助手 ====");
            System.out.println("1. 录入宠物信息");
            System.out.println("2. 查询宠物信息");
            System.out.println("3. 删除宠物信息");
            System.out.println("4. 添加健康记录");
            System.out.println("5. 查询健康记录");
            System.out.println("6. 退出系统");
            System.out.print("请选择操作：");

            int choice = input.nextInt();
            input.nextLine();

            switch (choice) {
                case 1:
                    addPetMenu();
                    break;
                case 2:
                    queryPetMenu();
                    break;
                case 3:
                    deletePetMenu();
                    break;
                case 4:
                    addHealthRecordMenu();
                    break;
                case 5:
                    queryHealthRecordMenu();
                    break;
                case 6:
                    manager.newways2();

                    System.out.println("系统已退出");
                    return;
                default:
                    System.out.println("无效选择，请重新输入");
            }
        }
    }

    private static void addPetMenu() {
        try {
            System.out.print("请输入宠物ID：");
            int id = input.nextInt();
            input.nextLine();
            System.out.print("请输入宠物名字：");
            String name = input.nextLine();
            System.out.print("请输入宠物品种：");
            String breed = input.nextLine();
            System.out.print("请输入宠物年龄：");
            int age = input.nextInt();
            input.nextLine();
            System.out.print("请输入宠物性别：");
            String gender = input.nextLine();

            Pet pet = new Pet(id, name, breed, age, gender);
            manager.addPet(pet);
            System.out.println("宠物录入成功！");

        } catch (PetException e) {
            System.out.println("录入失败：" + e.getMessage());
        } catch (Exception e) {
            System.out.println("输入格式错误，请重新输入");
            input.nextLine(); // 清空输入流
        }
    }
    private static void queryPetMenu() {
        System.out.print("\n请输入要查询的宠物ID：");
        int id = input.nextInt();
        Pet pet = manager.findPetById(id);
        if (pet != null) {
            System.out.println("查询结果：" + pet);
        } else {
            System.out.println("未找到该宠物");
        }
    }
    private static void deletePetMenu() {
        System.out.print("请输入要删除的宠物ID：");
        int id = input.nextInt();
        if (manager.deletePet(id)) {
            System.out.println("删除成功！");
        } else {
            System.out.println("删除失败：未找到该宠物");
        }
    }
    private static void addHealthRecordMenu() {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            System.out.print("请输入健康记录ID：");
            int recordId = input.nextInt();
            input.nextLine();
            System.out.print("请输入对应宠物ID：");
            int petId = input.nextInt();
            input.nextLine();
            System.out.print("请输入记录类型（疫苗/体检/就医）：");
            String recordType = input.nextLine();
            System.out.print("请输入记录日期（格式：yyyy-MM-dd）：");
            Date recordDate = sdf.parse(input.nextLine());
            System.out.print("请输入记录详情：");
            String details = input.nextLine();

            HealthRecord record = new HealthRecord(recordId, petId, recordType, recordDate, details);
            manager.addHealthRecord(record);
            System.out.println("健康记录添加成功！");

        } catch (PetException e) {
            System.out.println("添加失败：" + e.getMessage());
        } catch (ParseException e) {
            System.out.println("日期格式错误，请重新输入");
        } catch (Exception e) {
            System.out.println("输入格式错误，请重新输入");
            input.nextLine();
        }
    }
    private static void queryHealthRecordMenu() {
        System.out.print("请输入要查询的宠物ID：");
        int petId = input.nextInt();
        List<HealthRecord> records = manager.getHealthRecordsByPetId(petId);
        if (!records.isEmpty()) {
            System.out.println("\n健康记录列表：");
            for (HealthRecord record : records) {
                System.out.println(record);
            }
        } else {
            System.out.println("未找到该宠物的健康记录");
        }
    }

}
